package br.ucsal.laboratorio.model;

import java.io.Serializable;

public class Laboratorio implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String codigo;
	private String softwaresInstalados;
	private String cofiguracaoMaquinas;
	private Campus campus;
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getSoftwaresInstalados() {
		return softwaresInstalados;
	}
	public void setSoftwaresInstalados(String softwaresInstalados) {
		this.softwaresInstalados = softwaresInstalados;
	}
	public String getCofiguracaoMaquinas() {
		return cofiguracaoMaquinas;
	}
	public void setCofiguracaoMaquinas(String cofiguracaoMaquinas) {
		this.cofiguracaoMaquinas = cofiguracaoMaquinas;
	}
	public Campus getCampus() {
		return campus;
	}
	public void setCampus(Campus campus) {
		this.campus = campus;
	}
	
}
