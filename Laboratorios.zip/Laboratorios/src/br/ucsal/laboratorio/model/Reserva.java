package br.ucsal.laboratorio.model;

import java.io.Serializable;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import br.ucsal.laboratorio.model.Laboratorio;

public class Reserva implements Serializable{
	
	private static final long serialVersionUID = 1L;


	private String codigo;
	private String professor;
	private boolean fixa;
	
	private LocalDate data;
	private DayOfWeek DiaDaSemana;
	private LocalTime inicio;
	private LocalTime fim;
	private Laboratorio laboratorio;
	
	public Reserva() {
		// TODO Auto-generated constructor stub
	}
	
	public Reserva(String codigo, String professor, boolean fixa, LocalDate data, DayOfWeek diaDaSemana,
			LocalTime inicio, LocalTime fim, Laboratorio laboratorio) {
		super();
		this.codigo = codigo;
		this.professor = professor;
		this.fixa = fixa;
		this.data = data;
		DiaDaSemana = diaDaSemana;
		this.inicio = inicio;
		this.fim = fim;
		this.laboratorio = laboratorio;
	}
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getProfessor() {
		return professor;
	}
	public void setProfessor(String professor) {
		this.professor = professor;
	}
	public boolean isFixa() {
		return fixa;
	}
	public void setFixa(boolean fixa) {
		this.fixa = fixa;
	}
	public LocalDate getData() {
		return data;
	}
	public void setData(LocalDate data) {
		this.data = data;
	}
	public DayOfWeek getDiaDaSemana() {
		return DiaDaSemana;
	}
	public void setDiaDaSemana(DayOfWeek diaDaSemana) {
		DiaDaSemana = diaDaSemana;
	}
	public LocalTime getInicio() {
		return inicio;
	}
	public void setInicio(LocalTime inicio) {
		this.inicio = inicio;
	}
	public LocalTime getFim() {
		return fim;
	}
	public void setFim(LocalTime fim) {
		this.fim = fim;
	}
	public Laboratorio getLaboratorio() {
		return laboratorio;
	}
	public void setLaboratorio(Laboratorio laboratorio) {
		this.laboratorio = laboratorio;
	}
	
	
	
	
	
	
	
	
	
}
