package br.ucsal.laboratorio.model;

public enum Campus {
	FEDERACAO,PITUACU;
}




