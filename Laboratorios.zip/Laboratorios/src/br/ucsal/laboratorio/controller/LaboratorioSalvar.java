package br.ucsal.laboratorio.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucsal.laboratorio.Aplicacao;
import br.ucsal.laboratorio.model.Campus;
import br.ucsal.laboratorio.model.Laboratorio;

@WebServlet("/laboratoriosalvar")
public class LaboratorioSalvar extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		String codigo = request.getParameter("codigo");
		String software = request.getParameter("softwaresInstalados");
		String maquina = request.getParameter("cofiguracaoMaquinas");
		String campus = request.getParameter("campus");
		
		Laboratorio laboratorio = new Laboratorio();
		laboratorio.setCodigo(codigo);
		laboratorio.setSoftwaresInstalados(software);
		laboratorio.setCofiguracaoMaquinas(maquina);
		laboratorio.setCampus(Campus.valueOf(campus));

		
		
		Aplicacao app = (Aplicacao) request.getServletContext().getAttribute("app");
		

		if(app==null){
			app = new Aplicacao();
			request.getServletContext().setAttribute("app",app);
		}

		app.getLaboratorios().put(laboratorio.getCodigo(), laboratorio);
		response.sendRedirect("/Laboratorios/laboratorio.jsp");
		
	}
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
