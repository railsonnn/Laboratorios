package br.ucsal.laboratorio.controller;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucsal.laboratorio.Aplicacao;
import br.ucsal.laboratorio.model.Reserva;

/**
 * Servlet implementation class Disponibilidade
 */
@WebServlet("/disponibilidadeconsultar")
public class DisponibilidadeConsultar extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DisponibilidadeConsultar() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


		String diaDaSemana = request.getParameter("diaDaSemana");
		String data = request.getParameter("data");

		Aplicacao app = (Aplicacao) request.getServletContext().getAttribute("app");

		// lista de reservas para o dia e/ou data
		List<Reserva> resultado = new ArrayList<Reserva>();

		Map<String, Reserva> reserv = app.getReservas();
		Collection<Reserva> rev = reserv.values();
		try {
			
		if (data != null) {
			DateTimeFormatter forDat = DateTimeFormatter.ofPattern("d-M-yyyy");

			LocalDate ld = LocalDate.parse(data, forDat);

			for (Reserva re : rev) {
				if (re.getData().equals(ld)) {
					resultado.add(re);
				}

			}
			if (diaDaSemana != null) {
				DayOfWeek sem = DayOfWeek.valueOf(diaDaSemana);

				for (Reserva re : rev) {
					if (re.getData().equals(ld) || (re.getDiaDaSemana().equals(sem) && re.isFixa() == true)) {
						resultado.add(re);
					}
				}

			}

		}
		
	} catch (Exception e) {
		// TODO: handle exception
		System.out.println("Erro ao consultar");
		e.printStackTrace();
	}

		// Adiocina a lista de reservas para dia ou data na
		request.setAttribute("resultado", resultado);

		RequestDispatcher rd = request.getServletContext().getRequestDispatcher("/disponibilidade.jsp");
		rd.forward(request, response);
	} 


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}
