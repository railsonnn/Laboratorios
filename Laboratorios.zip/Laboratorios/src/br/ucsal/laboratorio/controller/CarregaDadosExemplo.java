package br.ucsal.laboratorio.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucsal.laboratorio.Aplicacao;
import br.ucsal.laboratorio.model.Campus;
import br.ucsal.laboratorio.model.Laboratorio;

/**
 * Servlet implementation class CarregaDadosExemplo
 */
@WebServlet("/exemplo")
public class CarregaDadosExemplo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarregaDadosExemplo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Aplicacao app = (Aplicacao) request.getServletContext().getAttribute("app");
		
		//verifica se app (objeto) da classe Aplicacao esta no escopo de Apllication
		if(app==null){
			app = new Aplicacao();
			request.getServletContext().setAttribute("app",app);
		}
		
		
		Laboratorio l1 = new Laboratorio();
		l1.setCodigo("LAMI01");
		l1.setCampus(Campus.PITUACU);
		l1.setCofiguracaoMaquinas("I3 4GB RAM");
		l1.setSoftwaresInstalados("WIN 7, Eclipse, Android Studio");
		
		Laboratorio l2 = new Laboratorio();
		l2.setCodigo("LAMI02");
		l2.setCampus(Campus.PITUACU);
		l2.setCofiguracaoMaquinas("I3 4GB RAM");
		l2.setSoftwaresInstalados("WIN 7, Eclipse, Android Studio");
		
		app.getLaboratorios().put(l1.getCodigo(), l1);
		app.getLaboratorios().put(l2.getCodigo(), l2);

	
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.getWriter().append("- Carga OK");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
