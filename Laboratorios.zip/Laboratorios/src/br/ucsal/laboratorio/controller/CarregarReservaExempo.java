package br.ucsal.laboratorio.controller;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucsal.laboratorio.Aplicacao;
import br.ucsal.laboratorio.model.Laboratorio;
import br.ucsal.laboratorio.model.Reserva;

/**
 * Servlet implementation class CarregarReservaExempo
 */
@WebServlet("/ResExempo")
public class CarregarReservaExempo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarregarReservaExempo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		DateTimeFormatter forData = DateTimeFormatter.ofPattern("d-M-yyyy");
		DateTimeFormatter forTime = DateTimeFormatter.ofPattern("H:mm");
		
		
		String codigo ="Cod01";
		String professor="Mario";
		
		boolean fixa= "on" == null ?  false:true;
			
		String dat = "01-02-2016";
		LocalDate data = LocalDate.parse(dat,forData);
		
		DayOfWeek diaDaSemana= DayOfWeek.valueOf("MONDAY");
		
		String Tini = "10:30";
		LocalTime inicio = LocalTime.parse(Tini, forTime);
		
		String Tfim = "12:30";
		LocalTime fim = LocalTime.parse(Tfim, forTime);
		
		
		Aplicacao app = (Aplicacao) request.getServletContext().getAttribute("app");
		if(app==null){
			app = new Aplicacao();
			request.getServletContext().setAttribute("app",app);
		}
		
		
		Map<String,Laboratorio> Labors = app.getLaboratorios();
		
		String key = "LAMI02";
		Laboratorio laboratorio = Labors.get(key);
		
		
		Reserva reserv = new Reserva(codigo, professor, fixa, data, diaDaSemana, inicio, fim, laboratorio);
		
		
		app.getReservas().put(reserv.getCodigo(), reserv);
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
