package br.ucsal.laboratorio.controller;

import br.ucsal.laboratorio.model.Laboratorio;

public class Reserva extends Laboratorio{

}
