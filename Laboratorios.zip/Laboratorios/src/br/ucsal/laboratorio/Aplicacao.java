package br.ucsal.laboratorio;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import br.ucsal.laboratorio.model.Laboratorio;
import br.ucsal.laboratorio.model.Reserva;

public class Aplicacao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Map<String,Laboratorio> laboratorios = new HashMap<String,Laboratorio>();
	
	private Map<String,Reserva> reservas = new HashMap<String,Reserva>();


	
	public Map<String,Laboratorio> getLaboratorios() {
		return laboratorios;
	}

	public void setLaboratorios(Map<String,Laboratorio> laboratorios) {
		this.laboratorios = laboratorios;
	}

	
	public Map<String,Reserva> getReservas() {
		return reservas;
	}

	public void setReservas(Map<String,Reserva> reservas) {
		this.reservas = reservas;
	}


	
	
}
